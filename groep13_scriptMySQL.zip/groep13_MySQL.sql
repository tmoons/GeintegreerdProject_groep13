-- ----------------- --
-- groep13_festivals --
-- ----------------- --

create database if not exists groep13_festivals;

Use groep13_festivals;




-- ------------------------- --
-- VERWIJDEREN OUDE TABELLEN --
-- ------------------------- --


SET foreign_key_checks = 0;
drop table if exists BandsPerFestival;
drop table if exists Podia;
drop table if exists Tickets;
drop table if exists FacPerCamp;
drop table if exists TickettypesPerFestival;
drop table if exists Bands;
drop table if exists Tickettypes;
drop table if exists CampingsPerFestival;
drop table if exists Campings;
drop table if exists GeregistreerdeGebruikers;
drop table if exists Faciliteiten;
drop table If exists Festivals;
SET foreign_key_checks = 1;




-- ----------------- --
-- AANMAKEN TABELLEN --
-- ----------------- --


-- Festivals --

create table IF NOT EXISTS Festivals
(
	 fest_id 		int		auto_increment 	NOT NULL
	,fest_naam		varchar(255) 	not null
	,fest_locatie		varchar(255) 	not null
	,fest_datum 		date		not null
	,fest_duur		int		not null

	,constraint 	pk_Festivals		primary key	(fest_id)
	
)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Faciliteiten --

create table IF NOT EXISTS Faciliteiten
(
	 fac_id			int		auto_increment 	not null
	,fac_omschr		varchar(255) 	not null
	,fac_eenhprijs		decimal 	not null

	,constraint 	pk_Faciliteiten		primary key	(fac_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- GeregistreerdeGebruikers --

create table IF NOT EXISTS GeregistreerdeGebruikers
(
	 gebr_id		int		auto_increment	not null
	,gebr_naam		varchar(255)	not null
	,gebr_adres		varchar(255)	
	,gebr_gebDat		date 		

	,constraint 		pk_GeregistreerdeGebruikers  primary key (gebr_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Campings --

create table IF NOT EXISTS Campings
(
	 camp_id		int		auto_increment 	not null
	,camp_adres		varchar(255)	not null
	,camp_cap		varchar(255) 	not null

	,constraint 		pk_Campings  	primary key	(camp_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- CampingsPerFestival --

create table IF NOT EXISTS CampingsPerFestival
(
	 fest_id		int		not null
	,camp_id		int		not null

	,constraint pk_CampingsPerFestival 		primary key	(fest_id, camp_id)
	,constraint fk_CampingsPerFestival_Festivals 	foreign key	(fest_id)	references Festivals(fest_id)
	,constraint fk_CampingsPerFestival_Campings	foreign key	(camp_id)	references Campings (camp_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Tickettypes --

create table IF NOT EXISTS Tickettypes
(
	 typ_id			int		auto_increment 	not null
	,typ_omschr		varchar(255)	not null
	,typ_prijs		decimal		not null
	,constraint 		pk_Tickettypes 	primary key (typ_id)
	
)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Bands --

create table IF NOT EXISTS Bands
(
	 band_id		int		auto_increment 	not null
	,band_naam		varchar(255) 	not null
	,band_soortMuziek	varchar(255) 	not null
	,band_url		varchar(255)	

	,constraint 		pk_Bands	primary key (band_id)
	
)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- TickettypesPerFestival --

create table IF NOT EXISTS TickettypesPerFestival
(
	 fest_id		int		not null
	,typ_id			int		not null
	,aantal			int 		not null

	,constraint	pk_TickettypesPerFestival	 	primary key	(fest_id, typ_id)
	,constraint 	fk_TickettypesPerFestival_Festivals	foreign	key	(fest_id)	references  Festivals  (fest_id)
	,constraint 	fk_TickettypesPerFestival_Tickettypes	foreign key	(typ_id)	references  Tickettypes (typ_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- FacPerCamp --

create table IF NOT EXISTS FacPerCamp
(
	 camp_id		int		not null
	,fac_id			int		not null
	,aantal			int		not null

	,constraint 	pk_FacPerCamp 				primary key	(camp_id, fac_id)
	,constraint	fk_FacPerCamp_Campings			foreign key	(camp_id)	references   Campings    (camp_id)
	,constraint	fk_FacPerCamp_Faciliteiten		foreign key	(fac_id)	references   Faciliteiten (fac_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Tickets --

create table IF NOT EXISTS Tickets
(
	 fest_id		int		not null
	,gebr_id		int		not null
	,typ_id			int 		not null
	,ticket_datum		date		not null

	,constraint 	pk_Tickets				primary key 	(fest_id, gebr_id)
	,constraint 	fk_Tickets_Festivals			foreign key	(fest_id)	references	Festivals                (fest_id)
	,constraint 	fk_Tickets_GeregistreerdeGebruikers	foreign key	(gebr_id)	references	GeregistreerdeGebruikers (gebr_id)
	,constraint 	fk_Tickets_Tickettypes			foreign key	(typ_id)	references	Tickettypes               (typ_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- Podia --

create table IF NOT EXISTS Podia
(
	 pod_id			int		auto_increment	not null
	,pod_omschr		varchar(255)	not null
	,pod_locatie		varchar(255) 	not null

	,constraint 	pk_Podia		primary key 	(pod_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;


-- BandsPerFestival --

create table IF NOT EXISTS BandsPerFestival
(
	 fest_id		int		not null
	,band_id		int		not null
	,pod_id			int		not null
	,datum			date		not null
	,uur			time		not null

	,constraint	pk_BandsPerFestival			primary key	(fest_id, band_id, pod_id)
	,constraint	fk_BandsPerFestival_Festivals		foreign key	(fest_id)	references	Festivals (fest_id)
	,constraint 	fk_BandsPerFestival_Bands		foreign key	(band_id) 	references	Bands     (band_id)
	,constraint 	fk_BandsPerFestival_Podia		foreign key	(pod_id)	references	Podia      (pod_id)

)DEFAULT CHARSET=utf8 ENGINE=InnoDB;






-- ------------------- --
-- INSERTS IN TABELLEN --
-- ------------------- --


insert into Bands 			values( 1 , 'Flogging molly'	, 'Irish punk'	, 'www.irish.uk'	);
insert into Bands 			values( 2 , 'Eminem'		, 'rap'		, 'www.irishrap.uk'	);
insert into Bands 			values( 3 , 'Dropkick murphys', 'Irish punk'	, 'www.irishdrop.uk'	);
insert into Bands 			values( 4 , 'BUNTU'		, 'linux'	, 'www.irishLinux.uk'	);
insert into Bands 			values( 5 , 'Linkin park'	, 'Rock'	, 'www.linkinp.com'	);
insert into Bands 			values( 6 , 'Dj coone'		, 'Hardstyle'	, 'www.Coone.com'	);

insert into GeregistreerdeGebruikers 	values( 1 , 'Seppe Willems'	, 'Eugeen Coolsstraat 74 3460 Bekkevoort'	, '1993/02/01');
insert into GeregistreerdeGebruikers 	values( 2 , 'Jens Heusdens'	, 'Heffelstraat 7A 3444 Rummen'			, '1992/08/27');
insert into GeregistreerdeGebruikers 	values( 3 , 'Cedric Vandewalle'	, 'Prinsenlaan 33 3630 Maasmechelen'		, '1993/11/28');
insert into GeregistreerdeGebruikers 	values( 4 , 'Moons Tim'		, 'Zwanenstraat 105 3520 Zonhoven'		, '1993/07/19');

insert into Festivals			values( 1 , 'Pukkelpop' , 'Hasselt' , '2013/07/02' , 3 );
insert into Festivals 			values( 2 , 'MarktRock' , 'Leuven'  , '2013/03/02' , 2 );

insert into Campings 			values( 1 , 'B5'  , 300 );
insert into Campings 			values( 2 , 'B10' , 200 );

insert into Faciliteiten		values( 1 , 'Douche kabines'  , 3  );
insert into Faciliteiten 		values( 2 , 'Workshop Tattoo' , 5  );

insert into FacPerCamp 			values( 1 , 1 , 2 );
insert into FacPerCamp 			values( 2 , 2 , 1 );

insert into Podia 			values( 1 , 'mainstream and headliners' , 'Mainstage' );
insert into Podia 			values( 2 , 'alternative acts'	  , 'AltRoom'	);

insert into Tickettypes 		values( 1 , 'Combi'	, 150	);
insert into Tickettypes			values( 2 , 'Zaterdag'	, 50	);

insert into BandsPerFestival		values( 1 , 1 , 1 , '2013/07/05' , '8:00:00' );

insert into CampingsPerFestival		values( 1 , 1 );
insert into CampingsPerFestival		values( 2 , 2 );
